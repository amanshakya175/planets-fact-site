import PlanetPage from "./PlanetPage";

const Home = () => {
	return (
		<>
			<PlanetPage />
		</>
	);
};

export default Home;
